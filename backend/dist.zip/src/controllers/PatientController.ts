import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { ApiResponse } from '../types';

const prisma = new PrismaClient();

export class PatientController {
  async getAllPatients(req: Request, res: Response) {
    try {
      const { page = 1, limit = 10 } = req.query;
      const skip = (Number(page) - 1) * Number(limit);

      const [patients, total] = await Promise.all([
        prisma.patient.findMany({
          skip,
          take: Number(limit),
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
                phone: true,
                age: true,
                gender: true,
                doshaType: true
              }
            }
          },
          orderBy: { createdAt: 'desc' }
        }),
        prisma.patient.count()
      ]);

      const response: ApiResponse = {
        success: true,
        message: 'Patients retrieved successfully',
        data: { patients, total }
      };

      res.json(response);
    } catch (error) {
      throw error;
    }
  }

  async createPatient(req: Request, res: Response) {
    try {
      const patientData = req.body;
      const patient = await prisma.patient.create({ data: patientData });

      const response: ApiResponse = {
        success: true,
        message: 'Patient created successfully',
        data: patient
      };

      res.status(201).json(response);
    } catch (error) {
      throw error;
    }
  }

  async getPatientById(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const patient = await prisma.patient.findUnique({
        where: { id },
        include: {
          user: true,
          doctor: true
        }
      });

      if (!patient) {
        const response: ApiResponse = {
          success: false,
          message: 'Patient not found'
        };
        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Patient retrieved successfully',
        data: patient
      };

      res.json(response);
    } catch (error) {
      throw error;
    }
  }

  async updatePatient(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const updateData = req.body;
      const patient = await prisma.patient.update({
        where: { id },
        data: updateData
      });

      const response: ApiResponse = {
        success: true,
        message: 'Patient updated successfully',
        data: patient
      };

      res.json(response);
    } catch (error) {
      throw error;
    }
  }

  async deletePatient(req: Request, res: Response) {
    try {
      const { id } = req.params;
      await prisma.patient.delete({ where: { id } });

      const response: ApiResponse = {
        success: true,
        message: 'Patient deleted successfully'
      };

      res.json(response);
    } catch (error) {
      throw error;
    }
  }

  async getPatientDietPlans(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      
      // First get the patient to find the userId
      const patient = await prisma.patient.findUnique({
        where: { id },
        select: { userId: true }
      });

      if (!patient) {
        const response: ApiResponse = {
          success: false,
          message: 'Patient not found'
        };
        res.status(404).json(response);
        return;
      }

      const dietPlans = await prisma.dietPlan.findMany({
        where: { patientId: patient.userId },
        include: { items: { include: { food: true, recipe: true } } }
      });

      const response: ApiResponse = {
        success: true,
        message: 'Diet plans retrieved successfully',
        data: dietPlans
      };

      res.json(response);
    } catch (error) {
      throw error;
    }
  }

  async getPatientHealthRecords(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      
      // First get the patient to find the userId
      const patient = await prisma.patient.findUnique({
        where: { id },
        select: { userId: true }
      });

      if (!patient) {
        const response: ApiResponse = {
          success: false,
          message: 'Patient not found'
        };
        res.status(404).json(response);
        return;
      }

      const healthRecords = await prisma.healthRecord.findMany({
        where: { patientId: patient.userId },
        orderBy: { date: 'desc' }
      });

      const response: ApiResponse = {
        success: true,
        message: 'Health records retrieved successfully',
        data: healthRecords
      };

      res.json(response);
    } catch (error) {
      throw error;
    }
  }
}



