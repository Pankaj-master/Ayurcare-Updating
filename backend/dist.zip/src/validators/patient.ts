import Joi from 'joi';

export const createPatientSchema = Joi.object({
  userId: Joi.string().required(),
  patientCode: Joi.string().required()
});

export const updatePatientSchema = Joi.object({
  patientCode: Joi.string().optional()
});

export const paginationSchema = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(10),
  sortBy: Joi.string().optional(),
  sortOrder: Joi.string().valid('asc', 'desc').default('desc')
});

export const idSchema = Joi.object({
  id: Joi.string().required()
});